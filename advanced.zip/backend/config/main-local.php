<?php

return [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'lSsiEKJ6w_1yIgJIz0O-K6eW6d9waTEX',
        ],
    ],
];
